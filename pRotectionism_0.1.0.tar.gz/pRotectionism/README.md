# pRotectionism
An R package dedicated to bringing protectionist policies to your code
